import os
import sys
import shutil
import argparse

def parse_argument():
    parser = argparse.ArgumentParser(description = 'Generate training parameter template in json.')
    parser.add_argument('--module' , type=str, help='parameter template of module(train/recondismic)' , required = True)
    parser.add_argument('--dest', type=str, help='generating destination path', required = False, default=".")

    if len(sys.argv) == 1:
        parser.print_help()
        exit()

    return parser.parse_args()


def main():
    args = parse_argument()

    module = args.module
    destination_path = args.dest
    if module == "train":
        file_name = "train.json"
    elif module == "recondismic":
        file_name = "train_mp.json"
    package_name = "cryoPROS"

    try:
        package_path = os.path.join(__import__(package_name).__path__._path[0])
        source_file_path = os.path.join(package_path, "options", file_name)

        if not os.path.exists(source_file_path):
            print(f"Source template file '{file_name}' not found.")
            return

        shutil.copy(source_file_path, destination_path)
        print(f"Json template file'{file_name}' has been copied to '{destination_path}' successfully.")

    except ImportError:
        print(f"Can't find package named '{package_name}', please check your installation of {package_name}.")

if __name__ == "__main__":
    main()